import { Body, Controller, Post } from '@nestjs/common';
import { PaymentsService } from './payments.service';
import { InitiatePaymentDto } from './dto/initiate-payment.dto';

@Controller('payments')
export class PaymentsController {
  constructor(private readonly service: PaymentsService) {}

  @Post('initiate')
  initiate(@Body() dto: InitiatePaymentDto) {
    return this.service.initiate(dto);
  }

  @Post('webhook/payfast')
  payfastWebhook(@Body() payload: Record<string, unknown>) {
    return this.service.handlePayfastWebhook(payload);
  }

  @Post('webhook/lulapay')
  lulapayWebhook(@Body() payload: Record<string, unknown>) {
    return this.service.handleLulapayWebhook(payload);
  }
}
