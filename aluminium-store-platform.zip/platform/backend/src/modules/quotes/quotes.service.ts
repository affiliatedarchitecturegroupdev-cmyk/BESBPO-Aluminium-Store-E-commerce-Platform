import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { CreateQuoteDto } from './dto/create-quotes.dto';
import { UpdateQuoteDto } from './dto/update-quotes.dto';

@Injectable()
export class QuotesService {
  constructor(private readonly prisma: PrismaService) {}

  findAll(query: Record<string, string>) {
    // quote listing — filters applied per query params (segment, category, etc.)
    return this.prisma.quote.findMany({ take: 50 });
  }

  async findOne(id: string) {
    const record = await this.prisma.quote.findUnique({ where: { id } });
    if (!record) throw new NotFoundException(`Quote ${id} not found`);
    return record;
  }

  create(dto: CreateQuoteDto) {
    return this.prisma.quote.create({ data: dto });
  }

  // Reads the buyer's current CartItems and re-shapes them as QuoteItem rows on a new
  // Quote — the SKU-exact cart line becomes a free-text description + approxAreaM2 line,
  // since a Quote is a pre-price-freeze RFQ rather than an exact-SKU order (see
  // docs/07-trade-accounts-quotes.md on why Quote and Order are deliberately separate models).
  async createFromCart(userId: string) {
    const cart = await this.prisma.cart.findUnique({
      where: { userId },
      include: { items: { include: { product: true } } },
    });
    if (!cart || cart.items.length === 0) {
      throw new BadRequestException('Your cart is empty — add items before requesting a quote');
    }

    const quoteNumber = `ALS-Q-${Date.now()}`;
    return this.prisma.quote.create({
      data: {
        quoteNumber,
        userId,
        status: 'SUBMITTED',
        items: {
          create: cart.items.map((item) => ({
            description: `${item.product.name} × ${item.quantity}`,
            subCategorySlug: item.product.subCategoryId,
            quantity: item.quantity,
          })),
        },
      },
      include: { items: true },
    });
  }

  update(id: string, dto: UpdateQuoteDto) {
    return this.prisma.quote.update({ where: { id }, data: dto });
  }

  remove(id: string) {
    return this.prisma.quote.delete({ where: { id } });
  }
}
