import { Body, Controller, Delete, Get, Param, Patch, Post, Query, Req, UseGuards } from '@nestjs/common';
import type { Request } from 'express';
import { QuotesService } from './quotes.service';
import { CreateQuoteDto } from './dto/create-quotes.dto';
import { UpdateQuoteDto } from './dto/update-quotes.dto';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';

@Controller('quotes')
export class QuotesController {
  constructor(private readonly service: QuotesService) {}

  @Get()
  findAll(@Query() query: Record<string, string>) {
    return this.service.findAll(query);
  }

  // Converts the buyer's current cart into a Quote/QuoteItem set — the "Request a Quote
  // Instead" flow at checkout, relative to cart contents. See docs/07-trade-accounts-quotes.md.
  @UseGuards(JwtAuthGuard)
  @Post('from-cart')
  createFromCart(@Req() req: Request & { user: { id: string } }) {
    return this.service.createFromCart(req.user.id);
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.service.findOne(id);
  }

  @Post()
  create(@Body() dto: CreateQuoteDto) {
    return this.service.create(dto);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() dto: UpdateQuoteDto) {
    return this.service.update(id, dto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.service.remove(id);
  }
}
