import { CanActivate, ExecutionContext, Injectable } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { PrismaService } from '../../prisma/prisma.service';

@Injectable()
export class CompanyRoleGuard implements CanActivate {
  constructor(
    private reflector: Reflector,
    private prisma: PrismaService,
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const required = this.reflector.get<string[]>('companyRoles', context.getHandler());
    if (!required) return true;
    const { user } = context.switchToHttp().getRequest();
    const record = await this.prisma.user.findUnique({ where: { id: user.id } });
    return !!record?.companyRole && required.includes(record.companyRole);
  }
}
