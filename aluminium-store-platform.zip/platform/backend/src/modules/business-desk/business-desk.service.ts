import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { InviteTeamMemberDto } from './dto/invite-team-member.dto';

@Injectable()
export class BusinessDeskService {
  constructor(private readonly prisma: PrismaService) {}

  private async requireCompanyId(userId: string): Promise<string> {
    const user = await this.prisma.user.findUnique({ where: { id: userId } });
    if (!user?.companyId) throw new NotFoundException('No company associated with this account');
    return user.companyId;
  }

  async getDashboard(userId: string) {
    const companyId = await this.requireCompanyId(userId);
    const [tradeAccount, openOrders, openQuotes, teamCount] = await Promise.all([
      this.prisma.tradeAccount.findUnique({ where: { companyId } }),
      this.prisma.order.count({ where: { user: { companyId }, status: { notIn: ['DELIVERED', 'CANCELLED'] } } }),
      this.prisma.quote.count({ where: { user: { companyId }, status: { in: ['SUBMITTED', 'UNDER_REVIEW', 'QUOTED'] } } }),
      this.prisma.user.count({ where: { companyId } }),
    ]);
    return {
      discountTier: tradeAccount?.discountTier ?? 'RETAIL',
      creditLimit: tradeAccount?.creditLimit ?? null,
      creditUsed: tradeAccount?.creditUsed ?? 0,
      openOrders,
      openQuotes,
      teamCount,
    };
  }

  async getCompanyOrders(userId: string) {
    const companyId = await this.requireCompanyId(userId);
    return this.prisma.order.findMany({
      where: { user: { companyId } },
      include: { items: true, user: { select: { name: true } } },
      orderBy: { createdAt: 'desc' },
    });
  }

  async getCompanyQuotes(userId: string) {
    const companyId = await this.requireCompanyId(userId);
    return this.prisma.quote.findMany({
      where: { user: { companyId } },
      include: { items: true },
      orderBy: { createdAt: 'desc' },
    });
  }

  async getStatements(userId: string) {
    const companyId = await this.requireCompanyId(userId);
    return this.prisma.statement.findMany({ where: { companyId }, orderBy: { periodStart: 'desc' } });
  }

  async getCreditPosition(userId: string) {
    const companyId = await this.requireCompanyId(userId);
    const account = await this.prisma.tradeAccount.findUnique({ where: { companyId } });
    if (!account) return { creditLimit: null, creditUsed: 0, available: null };
    const limit = account.creditLimit ? Number(account.creditLimit) : null;
    const used = Number(account.creditUsed);
    return { creditLimit: limit, creditUsed: used, available: limit != null ? limit - used : null };
  }

  async getTeam(userId: string) {
    const companyId = await this.requireCompanyId(userId);
    return this.prisma.user.findMany({
      where: { companyId },
      select: { id: true, name: true, email: true, companyRole: true, createdAt: true },
    });
  }

  async inviteTeamMember(userId: string, dto: InviteTeamMemberDto) {
    const companyId = await this.requireCompanyId(userId);
    // Creates a placeholder User pending their own sign-up/OAuth linking on first login —
    // consistent with the six sign-in options in the auth module.
    return this.prisma.user.create({
      data: { email: dto.email, name: dto.name, companyId, companyRole: dto.role as never, role: 'TRADE' },
    });
  }

  removeTeamMember(memberId: string) {
    return this.prisma.user.update({ where: { id: memberId }, data: { companyId: null, companyRole: null } });
  }
}
