import { Body, Controller, Get, Param, Post } from '@nestjs/common';
import { CmiRoutingService } from './cmi-routing.service';
import { RouteOrderDto } from './dto/route-order.dto';

@Controller('cmi-routing')
export class CmiRoutingController {
  constructor(private readonly service: CmiRoutingService) {}

  // Returns a ranked shortlist of partners — a human confirms, this never auto-assigns.
  @Post('suggest')
  suggest(@Body() dto: RouteOrderDto) {
    return this.service.suggestPartners(dto);
  }

  @Post(':orderId/confirm/:partnerId')
  confirm(@Param('orderId') orderId: string, @Param('partnerId') partnerId: string) {
    return this.service.confirmRouting(orderId, partnerId);
  }
}
