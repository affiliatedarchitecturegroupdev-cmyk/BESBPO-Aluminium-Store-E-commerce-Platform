import { IsIn, IsNumber, IsString } from 'class-validator';

export class RouteOrderDto {
  @IsString()
  orderId: string;

  @IsNumber()
  areaM2: number;

  @IsString()
  requiredCapability: string; // e.g. "Curtain Walling", "Shopfront Systems"

  @IsIn(['GAUTENG','KWAZULU_NATAL','WESTERN_CAPE','EASTERN_CAPE','LIMPOPO','MPUMALANGA','NORTH_WEST'])
  province: string;
}
