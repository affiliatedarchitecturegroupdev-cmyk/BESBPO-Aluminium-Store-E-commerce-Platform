import { Body, Controller, Post, Query } from '@nestjs/common';
import { NewsletterService } from './newsletter.service';
import { SubscribeDto } from './dto/subscribe.dto';

@Controller('newsletter')
export class NewsletterController {
  constructor(private readonly service: NewsletterService) {}

  @Post('subscribe')
  subscribe(@Body() dto: SubscribeDto) {
    return this.service.subscribe(dto);
  }

  // One-click unsubscribe link target — token-less by email for simplicity in this scaffold;
  // Phase 2 should sign this link so an email address alone can't unsubscribe someone else.
  @Post('unsubscribe')
  unsubscribe(@Query('email') email: string) {
    return this.service.unsubscribe(email);
  }
}
