import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { SubscribeDto } from './dto/subscribe.dto';

@Injectable()
export class NewsletterService {
  constructor(private readonly prisma: PrismaService) {}

  subscribe(dto: SubscribeDto) {
    return this.prisma.newsletterSubscriber.upsert({
      where: { email: dto.email },
      update: { active: true, unsubscribedAt: null },
      create: { email: dto.email, source: dto.source },
    });
  }

  unsubscribe(email: string) {
    return this.prisma.newsletterSubscriber.update({
      where: { email },
      data: { active: false, unsubscribedAt: new Date() },
    });
  }

  // Abandoned-cart tracking lives here rather than in the cart module — it's a marketing
  // recovery concern reading cart state, not cart business logic itself.
  async logAbandonedCart(cartId: string, userId: string | null) {
    return this.prisma.abandonedCartLog.upsert({
      where: { cartId },
      update: { lastActivityAt: new Date() },
      create: { cartId, userId, lastActivityAt: new Date() },
    });
  }
}
