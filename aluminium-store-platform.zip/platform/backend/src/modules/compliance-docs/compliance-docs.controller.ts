import { Body, Controller, Delete, Get, Param, Patch, Post, Query } from '@nestjs/common';
import { ComplianceDocsService } from './compliance-docs.service';
import { CreateComplianceDocDto } from './dto/create-compliance-docs.dto';
import { UpdateComplianceDocDto } from './dto/update-compliance-docs.dto';

@Controller('compliance-docs')
export class ComplianceDocsController {
  constructor(private readonly service: ComplianceDocsService) {}

  @Get()
  findAll(@Query() query: Record<string, string>) {
    return this.service.findAll(query);
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.service.findOne(id);
  }

  @Post()
  create(@Body() dto: CreateComplianceDocDto) {
    return this.service.create(dto);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() dto: UpdateComplianceDocDto) {
    return this.service.update(id, dto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.service.remove(id);
  }
}
