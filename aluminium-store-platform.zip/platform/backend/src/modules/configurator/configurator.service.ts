import { Injectable, HttpException } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { PriceRequestDto } from './dto/price-request.dto';

const PRICING_SERVICE_URL = process.env.PRICING_SERVICE_URL ?? 'http://pricing-service:8000';

@Injectable()
export class ConfiguratorService {
  constructor(private readonly prisma: PrismaService) {}

  // Calls the FastAPI pricing microservice, which runs the same formulas verified
  // in the Pricing Framework workbook (Area Rate / glazing upgrade / hardware allowance).
  async computePrice(dto: PriceRequestDto) {
    const res = await fetch(`${PRICING_SERVICE_URL}/price`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(dto),
    });
    if (!res.ok) {
      throw new HttpException('Pricing service unavailable', 502);
    }
    return res.json();
  }

  // Blocks sizes outside the AAAMSA-tested range for that configuration —
  // a certificate tested at one size does not cover a larger one.
  async validateSizeAgainstAAAMSARange(dto: PriceRequestDto) {
    const product = await this.prisma.product.findUnique({ where: { id: dto.productId } });
    if (!product) return { valid: false, reason: 'Unknown product' };
    const maxW = product.widthMm ?? 0;
    const maxH = product.heightMm ?? 0;
    const valid = dto.widthMm <= maxW && dto.heightMm <= maxH;
    return valid
      ? { valid: true }
      : { valid: false, reason: 'Outside AAAMSA-tested size range — route to RFQ', suggestRFQ: true };
  }
}
