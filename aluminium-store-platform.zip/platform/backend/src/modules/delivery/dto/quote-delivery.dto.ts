import { IsBoolean, IsIn, IsNumber } from 'class-validator';

export class QuoteDeliveryDto {
  @IsIn(['GAUTENG','KWAZULU_NATAL','WESTERN_CAPE','EASTERN_CAPE','LIMPOPO','MPUMALANGA','NORTH_WEST'])
  province: string;

  @IsNumber()
  weightKg: number;

  @IsBoolean()
  isFragile: boolean;
}
