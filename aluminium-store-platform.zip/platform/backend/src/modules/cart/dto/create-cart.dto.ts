// CreateCartItemDto — validated shape for creating a cartItem record.
// Extend with class-validator decorators (@IsString, @IsInt, etc.) during Phase 1 implementation.
export class CreateCartItemDto {
  [key: string]: unknown;
}
