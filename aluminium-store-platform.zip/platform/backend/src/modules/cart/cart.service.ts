import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { CreateCartItemDto } from './dto/create-cart.dto';
import { UpdateCartItemDto } from './dto/update-cart.dto';

@Injectable()
export class CartService {
  constructor(private readonly prisma: PrismaService) {}

  findAll(query: Record<string, string>) {
    // cartItem listing — filters applied per query params (segment, category, etc.)
    return this.prisma.cartItem.findMany({ take: 50 });
  }

  async findOne(id: string) {
    const record = await this.prisma.cartItem.findUnique({ where: { id } });
    if (!record) throw new NotFoundException(`CartItem ${id} not found`);
    return record;
  }

  create(dto: CreateCartItemDto) {
    return this.prisma.cartItem.create({ data: dto });
  }

  update(id: string, dto: UpdateCartItemDto) {
    return this.prisma.cartItem.update({ where: { id }, data: dto });
  }

  remove(id: string) {
    return this.prisma.cartItem.delete({ where: { id } });
  }
}
