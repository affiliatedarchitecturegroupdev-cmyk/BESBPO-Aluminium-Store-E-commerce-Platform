// CreateProductDto — validated shape for creating a product record.
// Extend with class-validator decorators (@IsString, @IsInt, etc.) during Phase 1 implementation.
export class CreateProductDto {
  [key: string]: unknown;
}
