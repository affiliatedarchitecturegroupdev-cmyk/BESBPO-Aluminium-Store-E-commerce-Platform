import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { CreateOrderDto } from './dto/create-orders.dto';
import { UpdateOrderDto } from './dto/update-orders.dto';

@Injectable()
export class OrdersService {
  constructor(private readonly prisma: PrismaService) {}

  findAll(query: Record<string, string>) {
    // order listing — filters applied per query params (segment, category, etc.)
    return this.prisma.order.findMany({ take: 50 });
  }

  async findOne(id: string) {
    const record = await this.prisma.order.findUnique({ where: { id } });
    if (!record) throw new NotFoundException(`Order ${id} not found`);
    return record;
  }

  create(dto: CreateOrderDto) {
    return this.prisma.order.create({ data: dto });
  }

  update(id: string, dto: UpdateOrderDto) {
    return this.prisma.order.update({ where: { id }, data: dto });
  }

  remove(id: string) {
    return this.prisma.order.delete({ where: { id } });
  }
}
