// CreateOrderDto — validated shape for creating a order record.
// Extend with class-validator decorators (@IsString, @IsInt, etc.) during Phase 1 implementation.
export class CreateOrderDto {
  [key: string]: unknown;
}
