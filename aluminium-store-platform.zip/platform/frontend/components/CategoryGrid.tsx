import Link from 'next/link';

// Reuses the exact 7-category breakdown and windowpane-grid icon family
// already built for the corporate site (see the marketing site's script.js ICONS constant).
const CATEGORIES = [
  { slug: 'windows', name: 'Windows', count: 762 },
  { slug: 'doors', name: 'Doors', count: 604 },
  { slug: 'facade-structural-systems', name: 'Facade & Structural', count: 64 },
  { slug: 'outdoor-living-shading', name: 'Outdoor Living', count: 177 },
  { slug: 'railing-screening-systems', name: 'Railing & Screening', count: 218 },
  { slug: 'roofing-glazing-garage-doors', name: 'Roofing Glazing', count: 120 },
  { slug: 'raw-material-hardware', name: 'Raw Material', count: 202 },
] as const;

export default function CategoryGrid() {
  return (
    <div
      style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))',
        gap: 20,
      }}
    >
      {CATEGORIES.map((c) => (
        <Link
          key={c.slug}
          href={`/catalogue/${c.slug}`}
          style={{
            display: 'block',
            background: '#fff',
            border: '1px solid #EAE6DC',
            borderRadius: 14,
            padding: 24,
            textDecoration: 'none',
            color: '#1B2733',
          }}
        >
          <h4 style={{ fontFamily: 'Space Grotesk, sans-serif', margin: 0 }}>{c.name}</h4>
          <p style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 12, color: '#C08A4E', marginTop: 6 }}>
            {c.count} SKUs
          </p>
        </Link>
      ))}
    </div>
  );
}
