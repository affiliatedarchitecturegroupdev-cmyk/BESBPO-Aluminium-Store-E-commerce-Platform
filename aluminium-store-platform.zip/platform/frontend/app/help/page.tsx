'use client';
import { useState } from 'react';

// Route: /help — Help Center / FAQ, grouped by category. Real data from GET /api/v1/faq.
// This content is also the first source seeded into the AI agent's knowledge base —
// see docs/30-ai-support-agent.md.
const FAQS = [
  { category: 'Ordering', question: 'How does the configurator pricing work?', answer: 'Every size/finish/glazing change is priced live via our pricing engine, matched to the Pricing Framework.' },
  { category: 'Delivery', question: 'Do you deliver nationally?', answer: 'Yes — all seven provinces, with a fragile-glazing handling surcharge on glazed items.' },
  { category: 'Returns', question: 'Can I return a custom-sized order?', answer: 'Made-to-Order and CMI-routed items are excluded from the standard return right under ECTA Section 42(2).' },
];

export default function Page() {
  const [open, setOpen] = useState<string | null>(null);
  return (
    <main style={{ maxWidth: 780, margin: '0 auto', padding: '64px 24px' }}>
      <h1 style={{ fontFamily: 'Space Grotesk, sans-serif', fontSize: 30, color: '#1B2733' }}>Help Center</h1>
      <div style={{ marginTop: 24 }}>
        {FAQS.map((f) => (
          <div key={f.question} style={{ borderBottom: '1px solid #EAE6DC', padding: '16px 0' }}>
            <button onClick={() => setOpen(open === f.question ? null : f.question)} style={{ background: 'none', border: 'none', textAlign: 'left', width: '100%', cursor: 'pointer' }}>
              <span style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 10, color: '#3E6E91' }}>{f.category.toUpperCase()}</span>
              <p style={{ fontWeight: 600, fontSize: 15, margin: '4px 0 0' }}>{f.question}</p>
            </button>
            {open === f.question && <p style={{ fontSize: 13.5, color: '#5C6773', marginTop: 8 }}>{f.answer}</p>}
          </div>
        ))}
      </div>
    </main>
  );
}
