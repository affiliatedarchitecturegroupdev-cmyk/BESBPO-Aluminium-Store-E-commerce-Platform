// Route: /cmi-partners
// Public-facing trust page for the Contract Manufacturing Issuer network.
export default function Page() {
  return (
    <main style={{ padding: '2rem' }}>
      <h1>CMI Partner Network</h1>
      <p>Public-facing trust page for the Contract Manufacturing Issuer network.</p>
    </main>
  );
}
