import HeroSliderStore from '../components/HeroSliderStore';
import AnnouncementTicker from '../components/AnnouncementTicker';
import TrustBadges from '../components/TrustBadges';
import SocialProofCounters from '../components/SocialProofCounters';
import CategoryGrid from '../components/CategoryGrid';
import ShopBySector from '../components/ShopBySector';
import ProductCarousel, { type CarouselProduct } from '../components/ProductCarousel';
import BundleGrid, { type BundleCard } from '../components/BundleGrid';
import AdSlot, { type AdData } from '../components/AdSlot';
import InstallationShowcase, { type FeaturedProject } from '../components/InstallationShowcase';
import ReviewsCarousel, { type ReviewCard } from '../components/ReviewsCarousel';
import NewsletterSignup from '../components/NewsletterSignup';
import BusinessDeskCTA from '../components/BusinessDeskCTA';

// Route: / (home) — 18 sections. Illustrative data below stands in for the real API calls
// (GET /api/v1/catalog?sort=trending, /api/v1/promotions/bundles, /api/v1/advertisements/active,
// /api/v1/projects/featured, product reviews) until the frontend's data layer is wired up
// in Phase 2 — see docs/16-roadmap.md.

const TRENDING: CarouselProduct[] = [
  { sku: 'ALS-PVD-0017', name: 'Pivot Entrance Door — 1509×2700mm', priceLabel: 'R 20,734' },
  { sku: 'ALS-SLD-0021', name: 'Sliding Door — 1809×2090mm', priceLabel: 'R 11,621' },
  { sku: 'ALS-CMW-0031', name: 'Casement Window — 1209×1209mm', priceLabel: 'R 4,714' },
  { sku: 'ALS-PRG-0004', name: 'Adjustable Louvre-Roof Pergola', priceLabel: 'R 65,859' },
];

const RECENT_ARRIVALS: CarouselProduct[] = [
  { sku: 'ALS-BBW-0002', name: 'Bay Window Unit — 5-Panel Bow', priceLabel: 'R 38,200', badge: 'NEW' },
  { sku: 'ALS-TTW-0014', name: 'Tilt & Turn Window — IGU Standard', priceLabel: 'R 9,880', badge: 'NEW' },
  { sku: 'ALS-SKY-0009', name: 'Ridge Skylight Strip', priceLabel: 'R 14,300', badge: 'NEW' },
];

const CLEARANCE: CarouselProduct[] = [
  { sku: 'ALS-SLW-0064', name: 'Sliding Window — Bronze Anodised, 2409×1509mm', priceLabel: 'R 12,480', originalPriceLabel: 'R 15,600', badge: '-20%' },
  { sku: 'ALS-HGD-0038', name: 'Hinged Door — Bronze Anodised', priceLabel: 'R 6,240', originalPriceLabel: 'R 7,800', badge: '-20%' },
];

const BUNDLES: BundleCard[] = [
  { id: 'b1', name: 'Starter Sliding Door Bundle', description: 'Door + heavy-duty roller set + multi-point lock', discountPct: 0.08, itemCount: 3 },
  { id: 'b2', name: 'Complete Window Hardware Kit', description: 'Handle, friction hinge, and stay arm', discountPct: 0.1, itemCount: 3 },
  { id: 'b3', name: 'Pergola + Louvre Screen Combo', discountPct: 0.06, itemCount: 2 },
];

const AD_1: AdData = { slot: 1, campaignName: 'Summer Glazing Upgrade — IGU from R550/m²', linkUrl: '/catalogue/windows' };
const AD_2: AdData = { slot: 2, campaignName: 'Trade Accounts: Apply This Week', linkUrl: '/business/dashboard' };
const AD_3: AdData = { slot: 3, campaignName: 'CMI Partner Network — National Capacity', linkUrl: '/cmi-partners' };

const FEATURED_PROJECTS: FeaturedProject[] = [
  { id: 'p1', title: 'Sandton Office Curtain Wall Retrofit', sector: 'Commercial', imageUrl: '' },
  { id: 'p2', title: 'Umhlanga Residential Estate — 42 Units', sector: 'Residential', imageUrl: '' },
];

const REVIEWS: ReviewCard[] = [
  { id: 'r1', rating: 5, comment: 'Configurator made pricing our order painless.', authorName: 'J. Naidoo', productName: 'Sliding Door' },
  { id: 'r2', rating: 4, comment: 'Good compliance paperwork, exactly what we needed for sign-off.', authorName: 'T. van Wyk', productName: 'Curtain Walling' },
];

export default function Page() {
  return (
    <main>
      <HeroSliderStore />
      <AnnouncementTicker />
      <TrustBadges />
      <SocialProofCounters />

      <section style={{ padding: '64px 32px', maxWidth: 1240, margin: '0 auto' }}>
        <h2 style={{ fontFamily: 'Space Grotesk, sans-serif', fontSize: 26, color: '#1B2733' }}>Shop by Category</h2>
        <div style={{ marginTop: 24 }}><CategoryGrid /></div>
      </section>

      <ShopBySector />
      <ProductCarousel anchorId="trending" title="Trending" subtitle="This month's most-configured products" products={TRENDING} />
      <AdSlot ad={AD_1} />
      <BundleGrid anchorId="bundles" bundles={BUNDLES} />
      <ProductCarousel anchorId="recent-arrivals" title="Recent Arrivals" products={RECENT_ARRIVALS} />
      <AdSlot ad={AD_2} />
      <ProductCarousel anchorId="clearance" title="Clearance Sale" subtitle="End-of-line finishes, while stock lasts" products={CLEARANCE} />
      <AdSlot ad={AD_3} />
      <InstallationShowcase projects={FEATURED_PROJECTS} />
      <ReviewsCarousel reviews={REVIEWS} />
      <NewsletterSignup />
      <BusinessDeskCTA />
    </main>
  );
}
