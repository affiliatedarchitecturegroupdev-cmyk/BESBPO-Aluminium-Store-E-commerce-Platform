// Route: /account/orders
// Past and in-progress orders.
export default function Page() {
  return (
    <main style={{ padding: '2rem' }}>
      <h1>Order History</h1>
      <p>Past and in-progress orders.</p>
    </main>
  );
}
