// Route: /account/addresses
// Manage delivery addresses.
export default function Page() {
  return (
    <main style={{ padding: '2rem' }}>
      <h1>Saved Addresses</h1>
      <p>Manage delivery addresses.</p>
    </main>
  );
}
