// Route: /account
// Buyer account dashboard.
export default function Page() {
  return (
    <main style={{ padding: '2rem' }}>
      <h1>Account Overview</h1>
      <p>Buyer account dashboard.</p>
    </main>
  );
}
