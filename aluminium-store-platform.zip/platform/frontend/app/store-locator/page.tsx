// Route: /store-locator — reuses the existing Location model (already used for stock
// levels/hub capacity) rather than a new model. Real data from a locations endpoint.
// See docs/27-content-pages.md.
const LOCATIONS = [
  { name: 'Gauteng Production Hub', province: 'Gauteng', isHub: true },
  { name: 'KZN Fabrication Yard', province: 'KwaZulu-Natal', isHub: true },
];

export default function Page() {
  return (
    <main style={{ maxWidth: 900, margin: '0 auto', padding: '64px 24px' }}>
      <h1 style={{ fontFamily: 'Space Grotesk, sans-serif', fontSize: 30, color: '#1B2733' }}>Store Locator</h1>
      <p style={{ fontSize: 13.5, color: '#5C6773', marginTop: 8 }}>Production hubs and Click & Collect points.</p>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 16, marginTop: 24 }}>
        {LOCATIONS.map((l) => (
          <div key={l.name} style={{ border: '1px solid #EAE6DC', borderRadius: 12, padding: 20 }}>
            <h4 style={{ fontFamily: 'Space Grotesk, sans-serif', margin: 0 }}>{l.name}</h4>
            <p style={{ fontSize: 12.5, color: '#5C6773', marginTop: 6 }}>{l.province}{l.isHub ? ' — Production Hub' : ''}</p>
          </div>
        ))}
      </div>
    </main>
  );
}
