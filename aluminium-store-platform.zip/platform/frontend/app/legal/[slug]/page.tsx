// Route: /legal/[slug] — one page serves all six legal documents (terms, privacy, cookies,
// returns, paia-manual, accessibility), rendering whichever LegalDocument is currently
// published for that slug. Real data from GET /api/v1/legal/:slug.
const TITLES: Record<string, string> = {
  terms: 'Terms & Conditions',
  privacy: 'Privacy Policy',
  cookies: 'Cookie Policy',
  returns: 'Returns & Refunds Policy',
  'paia-manual': 'PAIA Manual',
  accessibility: 'Accessibility Statement',
};

export default function Page({ params }: { params: { slug: string } }) {
  const title = TITLES[params.slug] ?? 'Legal Document';
  return (
    <main style={{ maxWidth: 780, margin: '0 auto', padding: '64px 24px' }}>
      <p style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 11, color: '#3E6E91', letterSpacing: '.1em' }}>LEGAL</p>
      <h1 style={{ fontFamily: 'Space Grotesk, sans-serif', fontSize: 30, color: '#1B2733' }}>{title}</h1>
      <p style={{ fontSize: 13, color: '#A9B2BD', marginTop: 8 }}>
        The current published version of this document is rendered here from the LegalDocument
        model — content pending legal review and sign-off (POPIA-accredited Information
        Officer / SARS tax advisor per docs/23-legal-tax-compliance.md) before this goes live.
      </p>
      <article style={{ marginTop: 32, fontSize: 14.5, lineHeight: 1.7, color: '#2A2A2A' }}>
        {/* Rendered from LegalDocument.bodyMarkdown once content is drafted and approved. */}
      </article>
    </main>
  );
}
