'use client';
import { useState } from 'react';

// Route: /login — six sign-in options: Email + Google, Facebook, X, Apple, Microsoft.
// OAuth buttons link straight to the backend's initiate routes (GET /api/v1/auth/:provider),
// which redirect to each provider's consent screen — see docs/18-authentication-sso.md.
const API = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:4000/api/v1';

const OAUTH_PROVIDERS = [
  { key: 'google', label: 'Continue with Google' },
  { key: 'facebook', label: 'Continue with Facebook' },
  { key: 'x', label: 'Continue with X' },
  { key: 'apple', label: 'Continue with Apple' },
  { key: 'microsoft', label: 'Continue with Microsoft' },
];

export default function Page() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  return (
    <main style={{ maxWidth: 420, margin: '0 auto', padding: '64px 24px' }}>
      <h1 style={{ fontFamily: 'Space Grotesk, sans-serif', fontSize: 26, color: '#1B2733' }}>Sign In</h1>
      <p style={{ fontSize: 12.5, color: '#A9B2BD', marginTop: 6 }}>Six ways in — no provider is the default.</p>

      <form style={{ marginTop: 24, display: 'flex', flexDirection: 'column', gap: 12 }}>
        <input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} style={inputStyle} />
        <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} style={inputStyle} />
        <button type="submit" style={{ padding: 12, background: '#1B2733', color: '#fff', border: 'none', borderRadius: 8, fontWeight: 600, cursor: 'pointer' }}>
          Sign In with Email
        </button>
      </form>

      <div style={{ display: 'flex', alignItems: 'center', gap: 12, margin: '24px 0' }}>
        <div style={{ flex: 1, height: 1, background: '#EAE6DC' }} />
        <span style={{ fontSize: 11, color: '#A9B2BD' }}>OR</span>
        <div style={{ flex: 1, height: 1, background: '#EAE6DC' }} />
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        {OAUTH_PROVIDERS.map((p) => (
          <a key={p.key} href={`${API}/auth/${p.key}`} style={oauthButtonStyle}>{p.label}</a>
        ))}
      </div>

      <p style={{ fontSize: 12.5, color: '#A9B2BD', marginTop: 24, textAlign: 'center' }}>
        New here? <a href="/register" style={{ color: '#3E6E91' }}>Create an account</a>
      </p>
    </main>
  );
}

const inputStyle: React.CSSProperties = { padding: 12, border: '1px solid #A9B2BD', borderRadius: 8 };
const oauthButtonStyle: React.CSSProperties = {
  padding: 12, border: '1px solid #A9B2BD', borderRadius: 8, textAlign: 'center',
  textDecoration: 'none', color: '#1B2733', fontSize: 13.5, fontWeight: 500,
};
