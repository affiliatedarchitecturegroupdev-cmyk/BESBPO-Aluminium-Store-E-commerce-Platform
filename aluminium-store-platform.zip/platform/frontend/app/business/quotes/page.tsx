// Route: /business/quotes — real data from GET /api/v1/business-desk/quotes.
export default function Page() {
  return (
    <main style={{ maxWidth: 1000, margin: '0 auto', padding: '64px 24px' }}>
      <h1 style={{ fontFamily: 'Space Grotesk, sans-serif', fontSize: 26, color: '#1B2733' }}>Company Quotes</h1>
      <div style={{ marginTop: 24 }} />
    </main>
  );
}
