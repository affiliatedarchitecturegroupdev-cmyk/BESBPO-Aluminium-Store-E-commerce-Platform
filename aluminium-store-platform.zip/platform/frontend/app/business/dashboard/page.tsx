// Route: /business/dashboard — real data from GET /api/v1/business-desk/dashboard.
// See docs/20-business-desk.md.
export default function Page() {
  return (
    <main style={{ maxWidth: 1000, margin: '0 auto', padding: '64px 24px' }}>
      <p style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 11, color: '#3E6E91' }}>BUSINESS DESK</p>
      <h1 style={{ fontFamily: 'Space Grotesk, sans-serif', fontSize: 28, color: '#1B2733' }}>Dashboard</h1>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginTop: 28 }}>
        {['Discount Tier', 'Open Orders', 'Open Quotes', 'Team Members'].map((label) => (
          <div key={label} style={{ border: '1px solid #EAE6DC', borderRadius: 12, padding: 20 }}>
            <p style={{ fontFamily: 'Space Grotesk, sans-serif', fontSize: 26, fontWeight: 700, margin: 0 }}>—</p>
            <p style={{ fontSize: 11.5, color: '#A9B2BD', marginTop: 4 }}>{label}</p>
          </div>
        ))}
      </div>
      <nav style={{ display: 'flex', gap: 20, marginTop: 32 }}>
        <a href="/business/orders" style={{ color: '#3E6E91' }}>Orders →</a>
        <a href="/business/quotes" style={{ color: '#3E6E91' }}>Quotes →</a>
        <a href="/business/statements" style={{ color: '#3E6E91' }}>Statements →</a>
        <a href="/business/credit" style={{ color: '#3E6E91' }}>Credit →</a>
        <a href="/business/team" style={{ color: '#3E6E91' }}>Team →</a>
      </nav>
    </main>
  );
}
