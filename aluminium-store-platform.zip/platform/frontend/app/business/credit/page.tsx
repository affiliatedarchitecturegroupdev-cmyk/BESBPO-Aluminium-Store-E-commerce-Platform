// Route: /business/credit — read-only credit position. Real data from GET /api/v1/business-desk/credit.
export default function Page() {
  return (
    <main style={{ maxWidth: 700, margin: '0 auto', padding: '64px 24px' }}>
      <h1 style={{ fontFamily: 'Space Grotesk, sans-serif', fontSize: 26, color: '#1B2733' }}>Credit Position</h1>
      <p style={{ fontSize: 12.5, color: '#A9B2BD', marginTop: 6 }}>Limit changes go through admin review, not self-service.</p>
    </main>
  );
}
