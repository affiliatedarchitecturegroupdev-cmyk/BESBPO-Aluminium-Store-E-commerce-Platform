// Route: /business/statements — downloadable period statements.
// Real data from GET /api/v1/business-desk/statements.
export default function Page() {
  return (
    <main style={{ maxWidth: 1000, margin: '0 auto', padding: '64px 24px' }}>
      <h1 style={{ fontFamily: 'Space Grotesk, sans-serif', fontSize: 26, color: '#1B2733' }}>Statements</h1>
      <div style={{ marginTop: 24 }} />
    </main>
  );
}
