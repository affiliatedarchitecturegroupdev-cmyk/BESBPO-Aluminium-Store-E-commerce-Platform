'use client';
import { useState } from 'react';

// Route: /business/team — OWNER-only: invite/remove team members.
// Real data from GET/POST /api/v1/business-desk/team.
export default function Page() {
  const [email, setEmail] = useState('');
  const [role, setRole] = useState('BUYER');

  return (
    <main style={{ maxWidth: 700, margin: '0 auto', padding: '64px 24px' }}>
      <h1 style={{ fontFamily: 'Space Grotesk, sans-serif', fontSize: 26, color: '#1B2733' }}>Team</h1>
      <p style={{ fontSize: 12.5, color: '#A9B2BD', marginTop: 6 }}>OWNER, BUYER, and VIEWER roles — see docs/20-business-desk.md.</p>
      <div style={{ display: 'flex', gap: 10, marginTop: 24 }}>
        <input placeholder="colleague@company.co.za" value={email} onChange={(e) => setEmail(e.target.value)} style={{ padding: 10, border: '1px solid #A9B2BD', borderRadius: 8, flex: 1 }} />
        <select value={role} onChange={(e) => setRole(e.target.value)} style={{ padding: 10, border: '1px solid #A9B2BD', borderRadius: 8 }}>
          <option value="BUYER">Buyer</option>
          <option value="VIEWER">Viewer</option>
          <option value="OWNER">Owner</option>
        </select>
        <button style={{ padding: '10px 18px', background: '#C08A4E', color: '#fff', border: 'none', borderRadius: 8, fontWeight: 600 }}>Invite</button>
      </div>
    </main>
  );
}
