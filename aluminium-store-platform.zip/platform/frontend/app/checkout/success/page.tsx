// Route: /checkout/success
// Post-payment confirmation and order summary.
export default function Page() {
  return (
    <main style={{ padding: '2rem' }}>
      <h1>Order Confirmation</h1>
      <p>Post-payment confirmation and order summary.</p>
    </main>
  );
}
