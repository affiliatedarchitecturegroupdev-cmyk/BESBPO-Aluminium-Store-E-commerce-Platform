// Route: /checkout
// Delivery address, payment method, order confirmation.
export default function Page() {
  return (
    <main style={{ padding: '2rem' }}>
      <h1>Checkout</h1>
      <p>Delivery address, payment method, order confirmation.</p>
    </main>
  );
}
