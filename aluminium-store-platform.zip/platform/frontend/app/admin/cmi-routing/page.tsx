// Route: /admin/cmi-routing
// Confirm partner assignment for routed orders.
export default function Page() {
  return (
    <main style={{ padding: '2rem' }}>
      <h1>Admin CMI Routing</h1>
      <p>Confirm partner assignment for routed orders.</p>
    </main>
  );
}
