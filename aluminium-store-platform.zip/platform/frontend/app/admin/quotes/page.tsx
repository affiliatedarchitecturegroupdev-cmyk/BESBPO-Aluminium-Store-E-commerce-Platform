// Route: /admin/quotes
// Review RFQs, trigger CMI-partner routing suggestions.
export default function Page() {
  return (
    <main style={{ padding: '2rem' }}>
      <h1>Admin Quote Review</h1>
      <p>Review RFQs, trigger CMI-partner routing suggestions.</p>
    </main>
  );
}
