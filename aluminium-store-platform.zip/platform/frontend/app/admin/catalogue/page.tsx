// Route: /admin/catalogue
// Import/merchandise the Master Product Catalogue.
export default function Page() {
  return (
    <main style={{ padding: '2rem' }}>
      <h1>Admin Catalogue Sync</h1>
      <p>Import/merchandise the Master Product Catalogue.</p>
    </main>
  );
}
