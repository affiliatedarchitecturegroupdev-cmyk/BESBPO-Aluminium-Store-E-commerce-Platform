// Route: /admin/trade-accounts
// Approve/decline pending trade accounts.
export default function Page() {
  return (
    <main style={{ padding: '2rem' }}>
      <h1>Admin Trade Account Review</h1>
      <p>Approve/decline pending trade accounts.</p>
    </main>
  );
}
