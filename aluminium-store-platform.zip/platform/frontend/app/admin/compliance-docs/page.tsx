// Route: /admin/compliance-docs
// Upload/attach AAAMSA, NRCS, SAFIERA documents.
export default function Page() {
  return (
    <main style={{ padding: '2rem' }}>
      <h1>Admin Compliance Documents</h1>
      <p>Upload/attach AAAMSA, NRCS, SAFIERA documents.</p>
    </main>
  );
}
