// Route: /admin
// Staff-only overview — orders, quotes, trade accounts.
export default function Page() {
  return (
    <main style={{ padding: '2rem' }}>
      <h1>Admin Dashboard</h1>
      <p>Staff-only overview — orders, quotes, trade accounts.</p>
    </main>
  );
}
