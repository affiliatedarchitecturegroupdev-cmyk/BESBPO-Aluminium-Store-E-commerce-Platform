'use client';
import { useState } from 'react';

// Route: /cart — real data from GET /api/v1/cart. Coupon validation calls
// POST /api/v1/promotions/coupons/validate (see docs/31-marketing-engine.md).
// "Request a Quote" converts the current cart into a Quote/QuoteItem set instead of
// checking out — for buyers who want a formal RFQ against their cart contents rather
// than an immediate purchase (see docs/07-trade-accounts-quotes.md).
const API = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:4000/api/v1';

export default function Page() {
  const [couponCode, setCouponCode] = useState('');
  const [couponResult, setCouponResult] = useState<{ discountAmount: number } | null>(null);
  const [couponError, setCouponError] = useState<string | null>(null);

  async function applyCoupon() {
    setCouponError(null);
    try {
      const res = await fetch(`${API}/promotions/coupons/validate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code: couponCode, cartValue: 0 }), // cartValue wired to real cart total in Phase 2
      });
      if (!res.ok) { setCouponError((await res.json()).message ?? 'Invalid coupon'); return; }
      setCouponResult(await res.json());
    } catch {
      setCouponError('Could not validate coupon right now.');
    }
  }

  async function requestQuoteFromCart() {
    // POST /api/v1/quotes/from-cart — converts current CartItems into a Quote + QuoteItems.
    await fetch(`${API}/quotes/from-cart`, { method: 'POST' });
  }

  return (
    <main style={{ maxWidth: 900, margin: '0 auto', padding: '64px 24px' }}>
      <h1 style={{ fontFamily: 'Space Grotesk, sans-serif', fontSize: 28, color: '#1B2733' }}>Your Cart</h1>

      <div style={{ marginTop: 24, border: '1px solid #EAE6DC', borderRadius: 12, padding: 20, minHeight: 120 }}>
        <p style={{ fontSize: 13, color: '#A9B2BD' }}>Cart line items render here from the cart module.</p>
      </div>

      <div style={{ display: 'flex', gap: 10, marginTop: 20, maxWidth: 380 }}>
        <input
          placeholder="Coupon code" value={couponCode} onChange={(e) => setCouponCode(e.target.value)}
          style={{ flex: 1, padding: 10, border: '1px solid #A9B2BD', borderRadius: 8 }}
        />
        <button onClick={applyCoupon} style={{ padding: '10px 18px', background: '#1B2733', color: '#fff', border: 'none', borderRadius: 8, cursor: 'pointer' }}>
          Apply
        </button>
      </div>
      {couponResult && <p style={{ fontSize: 12.5, color: '#3E6E91', marginTop: 8 }}>Discount applied: R{couponResult.discountAmount}</p>}
      {couponError && <p style={{ fontSize: 12.5, color: '#B03A32', marginTop: 8 }}>{couponError}</p>}

      <div style={{ display: 'flex', gap: 12, marginTop: 32 }}>
        <a href="/checkout" style={{ padding: '13px 28px', background: '#C08A4E', color: '#fff', borderRadius: 999, textDecoration: 'none', fontWeight: 600 }}>
          Proceed to Checkout
        </a>
        <button onClick={requestQuoteFromCart} style={{ padding: '13px 28px', background: 'transparent', color: '#1B2733', border: '1.5px solid #1B2733', borderRadius: 999, fontWeight: 600, cursor: 'pointer' }}>
          Request a Quote Instead
        </button>
      </div>
    </main>
  );
}
