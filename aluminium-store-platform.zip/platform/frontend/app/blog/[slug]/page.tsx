// Route: /blog/[slug] — real data from GET /api/v1/blog/:slug.
export default function Page({ params }: { params: { slug: string } }) {
  return (
    <main style={{ maxWidth: 780, margin: '0 auto', padding: '64px 24px' }}>
      <p style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 11, color: '#3E6E91' }}>{params.slug}</p>
      <h1 style={{ fontFamily: 'Space Grotesk, sans-serif', fontSize: 28, color: '#1B2733' }}>Post title pending CMS content</h1>
      <article style={{ marginTop: 24, fontSize: 14.5, lineHeight: 1.7, color: '#2A2A2A' }} />
    </main>
  );
}
