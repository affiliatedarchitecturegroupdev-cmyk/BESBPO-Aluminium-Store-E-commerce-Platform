import Link from 'next/link';

// Route: /blog — real data from GET /api/v1/blog. Illustrative list below until wired.
const POSTS = [
  { slug: 'choosing-glazing-packages', title: 'Standard vs IGU Double-Glazed: which do you need?', authorName: 'Aluminium Store Team' },
  { slug: 'cmi-model-explained', title: 'What "Contract Manufacturing Issuer" actually means', authorName: 'Aluminium Store Team' },
];

export default function Page() {
  return (
    <main style={{ maxWidth: 900, margin: '0 auto', padding: '64px 24px' }}>
      <h1 style={{ fontFamily: 'Space Grotesk, sans-serif', fontSize: 30, color: '#1B2733' }}>Blog</h1>
      <div style={{ marginTop: 28, display: 'flex', flexDirection: 'column', gap: 18 }}>
        {POSTS.map((p) => (
          <Link key={p.slug} href={`/blog/${p.slug}`} style={{ display: 'block', padding: 20, border: '1px solid #EAE6DC', borderRadius: 12, textDecoration: 'none', color: '#1B2733' }}>
            <h3 style={{ fontFamily: 'Space Grotesk, sans-serif', margin: 0 }}>{p.title}</h3>
            <p style={{ fontSize: 12, color: '#A9B2BD', marginTop: 6 }}>{p.authorName}</p>
          </Link>
        ))}
      </div>
    </main>
  );
}
