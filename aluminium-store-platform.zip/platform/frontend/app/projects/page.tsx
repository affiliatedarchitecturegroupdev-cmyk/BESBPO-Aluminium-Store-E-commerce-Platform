// Route: /projects — full case-study listing (the homepage shows only featured=true
// projects in the hero slider; this page lists all of them). Real data from GET /api/v1/projects.
export default function Page() {
  return (
    <main style={{ maxWidth: 1100, margin: '0 auto', padding: '64px 24px' }}>
      <h1 style={{ fontFamily: 'Space Grotesk, sans-serif', fontSize: 30, color: '#1B2733' }}>Projects</h1>
      <p style={{ fontSize: 13.5, color: '#5C6773', marginTop: 8 }}>Design → Manufacture (CMI) → Install, in practice.</p>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 18, marginTop: 28 }} />
    </main>
  );
}
