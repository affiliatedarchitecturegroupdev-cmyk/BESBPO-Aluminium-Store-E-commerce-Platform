// Route: /catalogue
// Sector-filterable browse across all 7 categories.
export default function Page() {
  return (
    <main style={{ padding: '2rem' }}>
      <h1>Full Catalogue</h1>
      <p>Sector-filterable browse across all 7 categories.</p>
    </main>
  );
}
