// Route: /catalogue/[category]/[subcategory]
// One of 31 sub-categories; entry point into the configurator.
export default function Page({ params }: { params: { category: string; subcategory: string } }) {
  return (
    <main style={{ padding: '2rem' }}>
      <h1>Sub-Category Page</h1>
      <p>One of 31 sub-categories; entry point into the configurator.</p>
      <p>Param category: {params.category}</p>
      <p>Param subcategory: {params.subcategory}</p>
    </main>
  );
}
