// Route: /catalogue/[category]
// One of 7 categories — Windows, Doors, Facade & Structural, etc.
export default function Page({ params }: { params: { category: string } }) {
  return (
    <main style={{ padding: '2rem' }}>
      <h1>Category Page</h1>
      <p>One of 7 categories — Windows, Doors, Facade & Structural, etc.</p>
      <p>Param category: {params.category}</p>
    </main>
  );
}
