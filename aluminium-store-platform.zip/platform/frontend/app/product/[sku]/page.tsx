import Configurator from '../../../components/Configurator';

// Route: /product/[sku]
// Single SKU detail page with the live configurator — see docs/03-configurator-spec.md.
// Data below is illustrative; wire to GET /api/v1/catalog/:sku for the real fetch.
export default function Page({ params }: { params: { sku: string } }) {
  const FINISHES = [
    { id: 'natural-anodised', name: 'Natural Anodised', hex: '#B8BEC4' },
    { id: 'satin-white', name: 'Satin White (RAL 9016)', hex: '#F1EFE9' },
    { id: 'charcoal-grey', name: 'Charcoal Grey (RAL 7016)', hex: '#37474F' },
    { id: 'bronze-anodised', name: 'Bronze Anodised', hex: '#6B4A2F' },
    { id: 'graphite-black', name: 'Graphite Black (RAL 9005)', hex: '#1B1B1B' },
  ];
  const GLAZING = [
    { id: 'standard', name: 'Standard Single-Glazed (4mm Clear Float)', upgradeRateM2: 0 },
    { id: 'igu', name: 'IGU Double-Glazed (4-12Ar-4 Low-E)', upgradeRateM2: 550 },
  ];

  return (
    <main style={{ padding: '2rem', display: 'grid', gridTemplateColumns: '1fr 480px', gap: 32 }}>
      <div>
        <p style={{ fontFamily: 'IBM Plex Mono, monospace', color: '#3E6E91' }}>{params.sku}</p>
        <h1 style={{ fontFamily: 'Space Grotesk, sans-serif' }}>Aluminium Sliding Window</h1>
        <p>2-Pane Slider (1 Fixed + 1 Sliding) — AAAMSA-tested up to 3009×1509mm.</p>
      </div>
      <Configurator
        productId={params.sku}
        sku={params.sku}
        maxWidthMm={3009}
        maxHeightMm={1509}
        finishes={FINISHES}
        glazingPackages={GLAZING}
        discountTier="RETAIL"
      />
    </main>
  );
}
