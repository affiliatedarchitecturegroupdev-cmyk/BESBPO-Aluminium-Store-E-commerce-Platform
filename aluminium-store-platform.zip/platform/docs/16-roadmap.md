# Roadmap — HITLAD Phases

Following the Group's proven Human-In-The-Loop Agentic Development model:

1. **Phase 1 — Foundation (Claude Code scaffold)**: schema, auth, catalog read APIs, basic
   storefront browsing. *This scaffold package is Phase 1's starting point.*
2. **Phase 2 — Configurator & Pricing**: FastAPI pricing microservice, configurator UI, live
   price computation, cart.
3. **Phase 3 — Orders, Payments & Trade Accounts**: checkout, PayFast/Lulapay/PayJustNow,
   trade account application/approval flow.
4. **Phase 4 — CMI Routing & Compliance**: partner routing engine, compliance-document
   attachment, quote/RFQ flow.
5. **Phase 5 — Delivery, Admin & Launch Hardening** (OpenHands agentic build-out, human PR
   review): delivery-zone/shipment tracking, admin CMS, load testing, security review.

## Sequencing note
Unlike Roofsteel, the configurator (Phase 2) is pulled earlier in this roadmap rather than
treated as a differentiator bolted on later — it is core to how a buyer actually prices a
window or door on this platform.
